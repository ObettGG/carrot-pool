const keyDep = () => 'keyDep';

module.exports = { keyDep };
